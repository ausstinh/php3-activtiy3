<?php
class Database{
    public static $dbservername = "localhost:8888";
    public static $dbusername = "root";
    public static $dbpassword = "root";
    public static $dbname = "ica4";
}