
<?php

class BankBusinessService
{

    function getCheckingBalance()
    {
        $servername = Database::$dbservername;
        $username = Database::$dbusername;
        $password = Database::$dbpassword;
        $dbname = Database::$dbname;

        $db = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $checking = new CheckAccountDataService($db);
        $balanceChecking = $checking->getBalance();
        $db = null;
        return $balanceChecking;
    }

    function getSavingsBalance()
    {
        $servername = Database::$dbservername;
        $username = Database::$dbusername;
        $password = Database::$dbpassword;
        $dbname = Database::$dbname;

        $db = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $savings = new SavingsAccountDataService($db);
        $balanceSavings = $savings->getBalance();
        $db = null;
        return $balanceSavings;
    }

    function transaction()
    {
        $servername = Database::$dbservername;
        $username = Database::$dbusername;
        $password = Database::$dbpassword;
        $dbname = Database::$dbname;

        $db = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $db->beginTransaction();

        $checking = new CheckAccountDataService($db);
        $balanceChecking = $checking->getBalance();
        $okChecking = $checking->updateBalance($balanceChecking - 100);

        $savings = new SavingsAccountDataService($db);
        $balanceSavings = $savings->getBalance();
        $okSavings = $savings->updateBalance($balanceSavings + 100);

        if ($okChecking && $okSavings) 
            $db->commit();
         else 
            $db->rollBack();
        
        $db = null;
    }
}

