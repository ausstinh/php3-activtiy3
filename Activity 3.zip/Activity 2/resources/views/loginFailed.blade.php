@extends('layouts.appmaster')
@section('title', 'Login PAssed Page')
@section('content')
<h2>Login Failed</h2>
<a href="login">Try Again</a>
@endsection