<html lang ="en">
<head>
<title>Who Am I</title></head>
<body>
<h2>Hello!</h2>
<?php  echo $firstName . " " . $lastName;?>
<br>
<a href= "askme">Go Again</a>
</body>


</html>