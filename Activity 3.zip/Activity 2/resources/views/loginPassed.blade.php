@extends('layouts.appmaster')
@section('title', 'Login PAssed Page')

@section('content')
@if($model->getUsername() == 'mark')
<h2>Login Passed</h2> 
@else
<h2>Login Other Passed</h2>
@endif
<a href="login2">Try Again</a>
@endsection