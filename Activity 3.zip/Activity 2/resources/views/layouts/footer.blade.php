<style>
    .footer
    {
        text-align: center;
        position: absolute;
        bottom: 0;
        width: 100%;
    }
</style>

<div class="footer">
	<h5>Copyright @2019 My Own Company Name</h5>
</div>