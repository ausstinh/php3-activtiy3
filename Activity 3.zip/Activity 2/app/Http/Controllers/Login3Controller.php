<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Exception;
use App\Models\UserModel;
use App\Services\Business\SecurityService;

class Login3Controller extends Controller
{
    public function index(Request $request){
        try{
            $this->validateForm($request);
        $username = $request->input("username");
        $password = $request->input("password");
        
        $user = new UserModel(-1, $username, $password);
        
        $service = new SecurityService();
        $status = $service->login($user);
        
        if($status)
        {
            $data = ['model' => $user];
            return view('loginPassed')->with($data);
        }
        else{
            return view('loginFailed');
        }
        }
        catch(ValidationException $el){
            throw $el;
        }
        
      }
        
        private function validateForm(Request $request)
        {
            $rules = ['username' => 'Required | Between: 4, 10 | Alpha',
                'password' => 'Required | Between: 4, 10'];
            
            $this->validate($request, $rules);
        }
 
    }
    
   
