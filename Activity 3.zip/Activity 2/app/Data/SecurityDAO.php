<?php

namespace APP\Data;

use \PDO;
use App\Servives\Utility\DatabaseException;
use PDOException;
use Illuminate\Support\Facades\Log;

Class SecurityDAO {
    
    private $databse = null;
    
    //best practice: do not create database connections in a data service
    function __construct($database)
    {
        $this->database = $database;
    }
    
    public function findByUser($user)
    {
        Log::info("Entering SecurityDAO, findByUser()");
        try{
            $name = $user->getUsername();
            $pw = $user->getPassword();
            $stmt = $this->db->prepare('SELECT ID, USERNAME, PASSWORD, FROM USERS WHERE USERNAME = :username AND PASSWORD = :password');
            $stmt->bindParam(':username', $name);
            $stmt->bindParam(':password', $pw);
            $stmt->execute();
            
            if($stmt->rowCount() == 1){
                Log::info("Exit SecurityDAo, findByUser() with true");
                return true;
            }
            else {         
                    Log::info("Exit SecurityDAo, findByUser() with false");
                    return false;
                }           
        }
            catch (PDOException $e)
            {
                //Best Practive: Catch all exceptions
                //log the exception, do not throw technology specific exceptions, and throw a custom exception
                Log::error("Exception: ", array("message" => $e->getMessage()));
                throw new DatabaseException("Database Exception: " . $e->getMessage(), 0, $e);
            }
        }
}